import { useEffect, useRef, useState } from 'react'
import { useLocalizacoes } from '../../api/hooks'
import { MapPin, RefreshCw, Clock } from 'lucide-react'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import 'dayjs/locale/pt-br'

dayjs.extend(relativeTime)
dayjs.locale('pt-br')

const COLORS = ['#00D68F', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#F97316']

export default function LocalizacaoPage() {
  const { data: localizacoes = [], refetch, isLoading } = useLocalizacoes()
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])
  const [selected, setSelected] = useState<any>(null)
  const [mapReady, setMapReady] = useState(false)

  // Load Leaflet CSS + JS dynamically
  useEffect(() => {
    if (document.getElementById('leaflet-css')) {
      setMapReady(true)
      return
    }
    const css = document.createElement('link')
    css.id = 'leaflet-css'
    css.rel = 'stylesheet'
    css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
    document.head.appendChild(css)

    const script = document.createElement('script')
    script.id = 'leaflet-js'
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
    script.onload = () => setMapReady(true)
    document.head.appendChild(script)
  }, [])

  // Initialize map
  useEffect(() => {
    if (!mapReady || !mapRef.current || mapInstanceRef.current) return
    const L = (globalThis as any).L
    if (!L) return

    const map = L.map(mapRef.current).setView([-23.55, -46.63], 12)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap',
      maxZoom: 19,
    }).addTo(map)

    mapInstanceRef.current = map
  }, [mapReady])

  // Update markers
  useEffect(() => {
    if (!mapInstanceRef.current || !localizacoes.length) return
    const L = (globalThis as any).L
    const map = mapInstanceRef.current

    // Clear old markers
    markersRef.current.forEach(m => map.removeLayer(m))
    markersRef.current = []

    const bounds: any[] = []

    localizacoes.forEach((loc: any, idx: number) => {
      if (!loc.lat || !loc.lng) return
      const color = COLORS[idx % COLORS.length]

      const icon = L.divIcon({
        className: '',
        html: `<div style="background:${color};width:36px;height:36px;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:14px">${loc.supervisor_nome?.charAt(0)?.toUpperCase() || '?'}</div>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      })

      const marker = L.marker([loc.lat, loc.lng], { icon })
        .addTo(map)
        .bindPopup(`
          <div style="min-width:180px">
            <strong>${loc.supervisor_nome}</strong><br/>
            <span style="color:#666;font-size:12px">${loc.condominio_nome}</span><br/>
            <span style="color:#999;font-size:11px">${dayjs(loc.momento).fromNow()}</span>
          </div>
        `)
        .on('click', () => setSelected(loc))

      markersRef.current.push(marker)
      bounds.push([loc.lat, loc.lng])
    })

    if (bounds.length > 0) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 })
    }
  }, [localizacoes, mapReady])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Localização dos supervisores</h1>
          <p className="text-sm text-gray-500 mt-1">Posições em tempo real baseadas nas vistorias</p>
        </div>
        <button
          onClick={() => refetch()}
          disabled={isLoading}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 shadow-sm transition-colors disabled:opacity-50"
        >
          <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
          Atualizar
        </button>
      </div>

      <div className="flex gap-4 h-[calc(100vh-12rem)]">
        {/* Map */}
        <div className="flex-1 rounded-xl overflow-hidden border border-gray-200 shadow-sm bg-gray-100">
          <div ref={mapRef} className="w-full h-full" />
        </div>

        {/* Supervisor list */}
        <div className="w-80 flex-shrink-0 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
            <h2 className="text-sm font-bold text-gray-900">Supervisores no mapa</h2>
            <p className="text-xs text-gray-500">{localizacoes.length} com localização</p>
          </div>
          <div className="flex-1 overflow-y-auto">
            {localizacoes.map((loc: any, idx: number) => {
              const color = COLORS[idx % COLORS.length]
              const isSelected = selected?.supervisor_id === loc.supervisor_id
              return (
                <button
                  key={loc.supervisor_id}
                  onClick={() => {
                    setSelected(loc)
                    const map = mapInstanceRef.current
                    if (map && loc.lat && loc.lng) {
                      map.setView([loc.lat, loc.lng], 16, { animate: true })
                    }
                  }}
                  className={`w-full text-left px-4 py-3 border-b border-gray-50 flex items-center gap-3 transition-colors ${
                    isSelected ? 'bg-emerald-50' : 'hover:bg-gray-50'
                  }`}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                    style={{ background: color }}
                  >
                    {loc.supervisor_nome?.charAt(0)?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 truncate">{loc.supervisor_nome}</div>
                    <div className="text-xs text-gray-500 truncate">{loc.condominio_nome}</div>
                    <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
                      <Clock size={10} />
                      {dayjs(loc.momento).fromNow()}
                    </div>
                  </div>
                  <MapPin size={14} className="text-gray-400" />
                </button>
              )
            })}

            {localizacoes.length === 0 && !isLoading && (
              <div className="p-8 text-center text-gray-400">
                <MapPin size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhum supervisor com localização nas últimas 24h</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
