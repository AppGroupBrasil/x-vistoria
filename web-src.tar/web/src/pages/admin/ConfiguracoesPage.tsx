import { useState, useEffect } from 'react'
import { useMinhaEmpresa } from '../../api/hooks'
import { api } from '../../api/client'
import { Settings, CheckCircle, List, Zap, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { useQueryClient } from '@tanstack/react-query'

const layouts = [
  {
    id: 'quiz',
    nome: 'Quiz (uma por vez)',
    descricao: 'Exibe uma pergunta por vez em tela cheia com botões grandes. Ideal para vistorias rápidas no celular.',
    icone: Zap,
    preview: [
      'Uma pergunta por tela',
      'Botões SIM / NÃO em destaque',
      'Navegação por swipe ou botão',
      'Progresso no topo',
      'Ditado por voz integrado',
    ],
  },
  {
    id: 'lista',
    nome: 'Lista completa',
    descricao: 'Mostra todas as perguntas agrupadas por categoria em uma página rolável. Ideal para vistorias detalhadas.',
    icone: List,
    preview: [
      'Todas as perguntas visíveis',
      'Agrupadas por categoria',
      'Barra de progresso geral',
      'Informações gerais no topo',
      'Conforme / Não conforme / N/A por item',
    ],
  },
]

export default function ConfiguracoesPage() {
  const { data: empresa, isLoading } = useMinhaEmpresa()
  const [layoutSelecionado, setLayoutSelecionado] = useState('quiz')
  const [salvando, setSalvando] = useState(false)
  const queryClient = useQueryClient()

  useEffect(() => {
    if (empresa?.layout_questionario) {
      setLayoutSelecionado(empresa.layout_questionario)
    }
  }, [empresa])

  const salvar = async (layoutId: string) => {
    setLayoutSelecionado(layoutId)
    setSalvando(true)
    try {
      await api.patch('/empresas/minha/configuracoes', { layout_questionario: layoutId })
      queryClient.invalidateQueries({ queryKey: ['minha-empresa'] })
      toast.success('Layout alterado com sucesso!')
    } catch {
      toast.error('Erro ao salvar configuração')
    } finally {
      setSalvando(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 size={32} className="animate-spin text-brand-navy" />
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 bg-brand-navy/10 rounded-xl flex items-center justify-center">
          <Settings size={22} className="text-brand-navy" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Configurações</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Personalize a experiência do vistoriador</p>
        </div>
      </div>

      {/* Layout selection */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-base font-bold text-gray-900 dark:text-white mb-1">Layout do questionário</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
          Escolha como o vistoriador verá as perguntas ao responder o checklist
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {layouts.map((layout) => {
            const isSelected = layoutSelecionado === layout.id
            const Icon = layout.icone
            return (
              <button
                key={layout.id}
                onClick={() => salvar(layout.id)}
                disabled={salvando}
                className={`relative text-left p-5 rounded-xl border-2 transition-all ${
                  isSelected
                    ? 'border-brand-navy bg-brand-navy/5 dark:bg-brand-navy/20 shadow-md'
                    : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 hover:shadow-sm'
                }`}
              >
                {/* Selected badge */}
                {isSelected && (
                  <div className="absolute top-3 right-3">
                    <CheckCircle size={22} className="text-brand-navy" />
                  </div>
                )}

                {/* Icon + name */}
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    isSelected ? 'bg-brand-navy text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
                  }`}>
                    <Icon size={20} />
                  </div>
                  <div>
                    <div className={`font-bold text-sm ${isSelected ? 'text-brand-navy' : 'text-gray-900 dark:text-white'}`}>
                      {layout.nome}
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">{layout.descricao}</p>

                {/* Feature list */}
                <ul className="space-y-1.5">
                  {layout.preview.map((item, i) => (
                    <li key={`${layout.id}-${i}`} className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                      <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-brand-navy' : 'bg-gray-300 dark:bg-gray-500'}`} />
                      {item}
                    </li>
                  ))}
                </ul>
              </button>
            )
          })}
        </div>

        {salvando && (
          <div className="flex items-center gap-2 mt-4 text-sm text-brand-navy">
            <Loader2 size={16} className="animate-spin" />
            Salvando...
          </div>
        )}
      </div>
    </div>
  )
}
