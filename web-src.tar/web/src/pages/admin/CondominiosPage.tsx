import { useState } from 'react'
import { useCondominios, useUsuarios, useExcluirCondominio } from '../../api/hooks'
import { api } from '../../api/client'
import { useQueryClient } from '@tanstack/react-query'
import { Plus, Building2, Users, MapPin, UserCheck, X, Search, Trash2, Ban, CheckCircle, HelpCircle, Pencil } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuth } from '../../store/auth'

const emptyForm = {
  nome: '', endereco: '', cep: '', cidade: '', estado: '',
  sindico_nome: '', sindico_email: '', sindico_telefone: '', total_unidades: '',
}

export default function CondominiosPage() {
  const { data: condominiosRes, isLoading } = useCondominios()
  const { data: usuariosRes } = useUsuarios({ limit: 1000 })
  const qc = useQueryClient()
  const { user } = useAuth()
  const excluirMutation = useExcluirCondominio()

  const condominios = condominiosRes?.data || []
  const usuarios = usuariosRes?.data || []

  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [supervisoresSelecionados, setSupervisoresSelecionados] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [busca, setBusca] = useState('')
  const [confirmDelete, setConfirmDelete] = useState<any>(null)
  const [showHelp, setShowHelp] = useState(false)

  // Edição
  const [editando, setEditando] = useState<any>(null)
  const [editForm, setEditForm] = useState(emptyForm)
  const [editSupervisores, setEditSupervisores] = useState<string[]>([])
  const [loadingEdit, setLoadingEdit] = useState(false)

  const supervisores = usuarios.filter((u: any) => u.role === 'supervisor')

  const isAdmin = user?.role === 'admin' || user?.role === 'master'

  const condominiosFiltrados = condominios.filter((c: any) => {
    if (!busca) return true
    const q = busca.toLowerCase()
    return (
      c.nome?.toLowerCase().includes(q) ||
      c.endereco?.toLowerCase().includes(q) ||
      c.cidade?.toLowerCase().includes(q) ||
      c.sindico_nome?.toLowerCase().includes(q) ||
      c.cep?.includes(q)
    )
  })

  const toggleSupervisor = (id: string, lista: string[], setLista: (v: string[]) => void) => {
    setLista(lista.includes(id) ? lista.filter((x) => x !== id) : [...lista, id])
  }

  const handleBloquear = async (c: any, e: React.MouseEvent) => {
    e.stopPropagation()
    try {
      const endpoint = c.ativo === false ? 'desbloquear' : 'bloquear'
      await api.patch(`/condominios/${c.id}/${endpoint}`)
      toast.success(c.ativo === false ? 'Condomínio desbloqueado!' : 'Condomínio bloqueado!')
      qc.invalidateQueries({ queryKey: ['condominios'] })
    } catch {
      toast.error('Erro ao alterar status')
    }
  }

  const handleExcluir = async () => {
    if (!confirmDelete) return
    try {
      await excluirMutation.mutateAsync(confirmDelete.id)
      toast.success('Condomínio excluído!')
      setConfirmDelete(null)
    } catch {
      toast.error('Erro ao excluir condomínio')
    }
  }

  const handleCriar = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const cond = await api.post('/condominios', {
        nome: form.nome,
        endereco: form.endereco,
        cep: form.cep || null,
        cidade: form.cidade || null,
        estado: form.estado || null,
        sindico_nome: form.sindico_nome || null,
        sindico_email: form.sindico_email || null,
        sindico_telefone: form.sindico_telefone || null,
        total_unidades: form.total_unidades ? Number(form.total_unidades) : null,
      })
      // Vincula supervisores selecionados
      await Promise.all(
        supervisoresSelecionados.map((sid) =>
          api.post(`/condominios/${cond.id}/supervisores/${sid}`)
        )
      )
      toast.success('Condomínio cadastrado!')
      qc.invalidateQueries({ queryKey: ['condominios'] })
      setShowModal(false)
      setForm(emptyForm)
      setSupervisoresSelecionados([])
    } catch {
      toast.error('Erro ao cadastrar condomínio')
    } finally {
      setLoading(false)
    }
  }

  const abrirEdicao = (c: any) => {
    setEditando(c)
    setEditForm({
      nome: c.nome || '', endereco: c.endereco || '', cep: c.cep || '', cidade: c.cidade || '',
      estado: c.estado || '', sindico_nome: c.sindico_nome || '',
      sindico_email: c.sindico_email || '', sindico_telefone: c.sindico_telefone || '',
      total_unidades: c.total_unidades ? String(c.total_unidades) : '',
    })
    setEditSupervisores((c.supervisores || []).map((s: any) => s.id))
  }

  const handleEditar = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoadingEdit(true)
    try {
      await api.patch(`/condominios/${editando.id}`, {
        nome: editForm.nome,
        endereco: editForm.endereco,
        cep: editForm.cep || null,
        cidade: editForm.cidade || null,
        estado: editForm.estado || null,
        sindico_nome: editForm.sindico_nome || null,
        sindico_email: editForm.sindico_email || null,
        sindico_telefone: editForm.sindico_telefone || null,
        total_unidades: editForm.total_unidades ? Number(editForm.total_unidades) : null,
      })

      // Supervisores atuais vs novos
      const atuais: string[] = (editando.supervisores || []).map((s: any) => s.id)
      const adicionar = editSupervisores.filter((id) => !atuais.includes(id))
      const remover = atuais.filter((id) => !editSupervisores.includes(id))

      await Promise.all([
        ...adicionar.map((sid) => api.post(`/condominios/${editando.id}/supervisores/${sid}`)),
        ...remover.map((sid) => api.delete(`/condominios/${editando.id}/supervisores/${sid}`)),
      ])

      toast.success('Condomínio atualizado!')
      qc.invalidateQueries({ queryKey: ['condominios'] })
      setEditando(null)
    } catch {
      toast.error('Erro ao atualizar condomínio')
    } finally {
      setLoadingEdit(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Condomínios</h1>
          <p className="text-sm text-gray-500">{condominios.length} cadastrados</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowHelp(true)} className="p-2 text-gray-400 hover:text-brand-navy rounded-lg hover:bg-gray-100" title="Ajuda">
            <HelpCircle size={20} />
          </button>
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={16} /> Novo condomínio
          </button>
        </div>
      </div>

      {/* Busca */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="input pl-9"
          placeholder="Buscar por nome, endereço, cidade, síndico ou CEP..."
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {condominiosFiltrados.map((c: any) => (
          <div
            key={c.id}
            className={`card p-5 hover:shadow-md transition-shadow ${c.ativo === false ? 'opacity-60 border-red-200' : ''}`}
          >
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 bg-brand-light rounded-xl flex items-center justify-center flex-shrink-0">
                <Building2 size={20} className="text-brand-navy" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-900 truncate">{c.nome}</h3>
                <div className="flex items-center gap-2">
                  {c.total_unidades && (
                    <p className="text-xs text-gray-500">{c.total_unidades} unidades</p>
                  )}
                  {c.ativo === false && (
                    <span className="text-xs bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full font-medium">Bloqueado</span>
                  )}
                </div>
              </div>
              {/* Action buttons */}
              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={(e) => { e.stopPropagation(); abrirEdicao(c) }}
                  className="p-1.5 rounded-lg hover:bg-emerald-50 text-gray-400 hover:text-emerald-600"
                  title="Editar"
                >
                  <Pencil size={16} />
                </button>
                {isAdmin && (
                  <>
                    <button
                      onClick={(e) => handleBloquear(c, e)}
                      className={`p-1.5 rounded-lg hover:bg-gray-100 ${c.ativo === false ? 'text-green-500 hover:text-green-700' : 'text-yellow-500 hover:text-yellow-700'}`}
                      title={c.ativo === false ? 'Desbloquear' : 'Bloquear'}
                    >
                      {c.ativo === false ? <CheckCircle size={16} /> : <Ban size={16} />}
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setConfirmDelete(c) }}
                      className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600"
                      title="Excluir"
                    >
                      <Trash2 size={16} />
                    </button>
                  </>
                )}
              </div>
            </div>
            <div className="space-y-1.5 text-sm text-gray-500">
              {c.endereco && (
                <div className="flex items-center gap-1.5">
                  <MapPin size={13} /> {c.endereco}
                  {c.cidade && `, ${c.cidade}/${c.estado}`}
                </div>
              )}
              {c.sindico_nome && (
                <div className="flex items-center gap-1.5">
                  <Users size={13} /> Síndico: {c.sindico_nome}
                </div>
              )}
            </div>
            {/* Supervisores vinculados */}
            {c.supervisores?.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1.5">
                  <UserCheck size={13} /> Supervisores responsáveis
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {c.supervisores.map((s: any) => (
                    <span key={s.id} className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-medium">
                      {s.nome}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {(!c.supervisores || c.supervisores.length === 0) && (
              <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-400 flex items-center gap-1">
                <UserCheck size={13} /> Nenhum supervisor vinculado
              </div>
            )}
          </div>
        ))}
        {condominiosFiltrados.length === 0 && !isLoading && (
          <div className="col-span-3 card p-12 text-center text-gray-400">
            <Building2 size={40} className="mx-auto mb-3 opacity-30" />
            <p className="text-sm">{busca ? 'Nenhum condomínio encontrado' : 'Nenhum condomínio cadastrado'}</p>
          </div>
        )}
      </div>

      {/* Modal criar */}
      {showModal && (
        <CondominioModal
          title="Novo Condomínio"
          form={form}
          setForm={setForm}
          supervisores={supervisores}
          supervisoresSelecionados={supervisoresSelecionados}
          onToggleSupervisor={(id) => toggleSupervisor(id, supervisoresSelecionados, setSupervisoresSelecionados)}
          onSubmit={handleCriar}
          onClose={() => { setShowModal(false); setForm(emptyForm); setSupervisoresSelecionados([]) }}
          loading={loading}
          submitLabel="Cadastrar"
        />
      )}

      {/* Modal editar */}
      {editando && (
        <CondominioModal
          title="Editar Condomínio"
          form={editForm}
          setForm={setEditForm}
          supervisores={supervisores}
          supervisoresSelecionados={editSupervisores}
          onToggleSupervisor={(id) => toggleSupervisor(id, editSupervisores, setEditSupervisores)}
          onSubmit={handleEditar}
          onClose={() => setEditando(null)}
          loading={loadingEdit}
          submitLabel="Salvar alterações"
        />
      )}

      {/* Modal confirmar exclusão */}
      {confirmDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card w-full max-w-sm p-6 text-center">
            <Trash2 size={40} className="mx-auto mb-3 text-red-400" />
            <h3 className="text-lg font-bold text-gray-900 mb-2">Excluir condomínio?</h3>
            <p className="text-sm text-gray-500 mb-4">
              <strong>{confirmDelete.nome}</strong> será excluído permanentemente. Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1">Cancelar</button>
              <button onClick={handleExcluir} disabled={excluirMutation.isPending} className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-xl text-sm font-medium">
                {excluirMutation.isPending ? 'Excluindo...' : 'Excluir'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal ajuda */}
      {showHelp && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold flex items-center gap-2"><HelpCircle size={20} className="text-brand-navy" /> Como usar</h2>
              <button onClick={() => setShowHelp(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="space-y-4 text-sm text-gray-600">
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">1</div>
                <div><p className="font-medium text-gray-900">Cadastrar condomínio</p><p>Clique em "Novo condomínio" e preencha os dados. Vincule supervisores responsáveis.</p></div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">2</div>
                <div><p className="font-medium text-gray-900">Editar</p><p>Clique no card do condomínio para abrir o formulário de edição.</p></div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">3</div>
                <div><p className="font-medium text-gray-900">Bloquear / Desbloquear</p><p>Use o ícone de bloqueio no card para impedir temporariamente o uso do condomínio.</p></div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">4</div>
                <div><p className="font-medium text-gray-900">Excluir</p><p>Use o ícone de lixeira para remover permanentemente o condomínio. Apenas administradores podem excluir.</p></div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-xs">5</div>
                <div><p className="font-medium text-gray-900">Buscar</p><p>Use o campo de busca para filtrar por nome, endereço, cidade, síndico ou CEP.</p></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function CondominioModal({
  title, form, setForm, supervisores, supervisoresSelecionados, onToggleSupervisor,
  onSubmit, onClose, loading, submitLabel,
}: Readonly<{
  title: string
  form: typeof emptyForm
  setForm: (f: typeof emptyForm) => void
  supervisores: any[]
  supervisoresSelecionados: string[]
  onToggleSupervisor: (id: string) => void
  onSubmit: (e: React.FormEvent) => void
  onClose: () => void
  loading: boolean
  submitLabel: string
}>) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="card w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
        </div>
        <form onSubmit={onSubmit} className="space-y-3">
          <div>
            <label htmlFor="cond-nome" className="label">Nome *</label>
            <input id="cond-nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="input" required />
          </div>
          <div>
            <label htmlFor="cond-endereco" className="label">Endereço *</label>
            <input id="cond-endereco" value={form.endereco} onChange={(e) => setForm({ ...form, endereco: e.target.value })} className="input" required />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label htmlFor="cond-cep" className="label">CEP</label>
              <input id="cond-cep" value={form.cep} onChange={(e) => setForm({ ...form, cep: e.target.value.replaceAll(/\D/g, '').slice(0, 8) })} className="input" placeholder="00000000" maxLength={8} />
            </div>
            <div>
              <label htmlFor="cond-cidade" className="label">Cidade</label>
              <input id="cond-cidade" value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} className="input" />
            </div>
            <div>
              <label htmlFor="cond-estado" className="label">Estado</label>
              <input id="cond-estado" value={form.estado} onChange={(e) => setForm({ ...form, estado: e.target.value })} className="input" maxLength={2} placeholder="SP" />
            </div>
          </div>
          <div>
            <label htmlFor="cond-sindico-nome" className="label">Nome do síndico</label>
            <input id="cond-sindico-nome" value={form.sindico_nome} onChange={(e) => setForm({ ...form, sindico_nome: e.target.value })} className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="cond-sindico-email" className="label">Email do síndico</label>
              <input id="cond-sindico-email" type="email" value={form.sindico_email} onChange={(e) => setForm({ ...form, sindico_email: e.target.value })} className="input" />
            </div>
            <div>
              <label htmlFor="cond-sindico-tel" className="label">Telefone do síndico</label>
              <input id="cond-sindico-tel" value={form.sindico_telefone} onChange={(e) => setForm({ ...form, sindico_telefone: e.target.value })} className="input" />
            </div>
          </div>
          <div>
            <label htmlFor="cond-unidades" className="label">Total de unidades</label>
            <input id="cond-unidades" type="number" value={form.total_unidades} onChange={(e) => setForm({ ...form, total_unidades: e.target.value })} className="input" />
          </div>

          {/* Supervisores responsáveis */}
          <div>
            <label className="label flex items-center gap-1.5">
              <UserCheck size={14} /> Supervisores responsáveis
            </label>
            {supervisores.length === 0 ? (
              <p className="text-sm text-gray-400 py-2">Nenhum supervisor cadastrado.</p>
            ) : (
              <div className="border border-gray-200 rounded-xl divide-y divide-gray-100 max-h-44 overflow-y-auto">
                {supervisores.map((s: any) => (
                  <label key={s.id} className="flex items-center gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supervisoresSelecionados.includes(s.id)}
                      onChange={() => onToggleSupervisor(s.id)}
                      className="w-4 h-4 accent-brand-navy"
                    />
                    <div>
                      <div className="text-sm font-medium text-gray-800">{s.nome}</div>
                      <div className="text-xs text-gray-400">{s.email}</div>
                    </div>
                    <span className="sr-only">{s.nome}</span>
                  </label>
                ))}
              </div>
            )}
            {supervisoresSelecionados.length > 0 && (
              <p className="text-xs text-emerald-600 mt-1">
                {supervisoresSelecionados.length} supervisor(es) selecionado(s) — este condomínio aparecerá apenas para eles.
              </p>
            )}
          </div>

          <div className="flex gap-3 pt-2">
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? 'Salvando...' : submitLabel}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary">Cancelar</button>
          </div>
        </form>
      </div>
    </div>
  )
}
