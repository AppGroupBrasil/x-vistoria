﻿import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../store/auth'
import toast from 'react-hot-toast'
import { Eye, EyeOff, MessageCircle } from 'lucide-react'
import SeoHead from '../components/SeoHead'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await login(email, senha)
      navigate('/dashboard')
    } catch (err: any) {
      toast.error(err?.message || 'Email ou senha inválidos')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-brand-navy flex items-center justify-center p-4">
      <SeoHead title="Login — X Vistoria" description="Acesse o painel de vistoria condominial. Gerencie vistorias, checklists e relatórios." />
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <img src="/logo.png" alt="X Vistoria" className="w-16 h-16 mx-auto mb-3 rounded-2xl" />
          <div className="text-white font-bold text-3xl">X Vistoria</div>
          <div className="text-brand-green/60 text-xs tracking-widest uppercase mt-1">Condominial</div>
        </div>

        <div className="card p-8">
          <h1 className="text-xl font-bold text-gray-900 mb-1">Entrar</h1>
          <p className="text-sm text-gray-500 mb-6">Acesse o painel administrativo</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-email" className="label">Email</label>
              <input
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                placeholder="seu@email.com"
                required
              />
            </div>
            <div>
              <label htmlFor="login-senha" className="label">Senha</label>
              <div className="relative">
                <input
                  id="login-senha"
                  type={show ? 'text' : 'password'}
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="input pr-10"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {show ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
              {loading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>

          <div className="mt-4 text-center">
            <Link to="/esqueci-senha" className="text-sm text-brand-green hover:underline">
              Esqueceu sua senha?
            </Link>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100 text-center">
            <p className="text-sm text-gray-500 mb-3">Ainda não tem conta?</p>
            <Link
              to="/register"
              className="block w-full text-center py-2.5 px-4 rounded-lg border-2 border-brand-green text-brand-green font-semibold hover:bg-brand-green hover:text-white transition-colors"
            >
              Cadastre-se
            </Link>
          </div>
        </div>

        <a
          href="https://wa.me/5511933284364?text=Ol%C3%A1%2C%20preciso%20de%20ajuda%20com%20o%20App%20Vistoria"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-lg bg-green-500 hover:bg-green-600 text-white font-semibold transition-colors"
        >
          <MessageCircle size={18} />
          Suporte via WhatsApp
        </a>

        <p className="text-center text-white/30 text-xs mt-6">
          X Vistoria Condominial © {new Date().getFullYear()}
        </p>
      </div>
    </div>
  )
}
