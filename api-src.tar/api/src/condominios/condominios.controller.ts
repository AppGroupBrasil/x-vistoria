import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { CondominiosService } from './condominios.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard, Roles } from '../auth/roles.guard';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { IsString, IsOptional, IsEmail, IsInt, Min } from 'class-validator';

class CriarCondominioDto {
  @IsString() nome: string;
  @IsString() endereco: string;
  @IsOptional() @IsString() cidade?: string;
  @IsOptional() @IsString() estado?: string;
  @IsOptional() @IsString() cep?: string;
  @IsOptional() @IsString() sindico_nome?: string;
  @IsOptional() @IsEmail() sindico_email?: string;
  @IsOptional() @IsString() sindico_telefone?: string;
  @IsOptional() @IsInt() @Min(1) total_unidades?: number;
}

class AtualizarCondominioDto {
  @IsOptional() @IsString() nome?: string;
  @IsOptional() @IsString() endereco?: string;
  @IsOptional() @IsString() cidade?: string;
  @IsOptional() @IsString() estado?: string;
  @IsOptional() @IsString() cep?: string;
  @IsOptional() @IsString() sindico_nome?: string;
  @IsOptional() @IsEmail() sindico_email?: string;
  @IsOptional() @IsString() sindico_telefone?: string;
  @IsOptional() @IsInt() @Min(1) total_unidades?: number;
}

@ApiTags('condominios')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('condominios')
export class CondominiosController {
  constructor(private readonly service: CondominiosService) {}

  @Get()
  listar(@Request() req, @Query() query: any) {
    const supervisorId = req.user.role === 'supervisor' ? req.user.sub : undefined;
    return this.service.listar(req.user.empresa_id, supervisorId, query);
  }

  @Get(':id')
  buscar(@Param('id') id: string) { return this.service.buscarPorId(id); }

  @Post()
  criar(@Body() dto: CriarCondominioDto, @Request() req) { return this.service.criar(dto, req.user.empresa_id); }

  @Patch(':id')
  @Roles('admin', 'master')
  atualizar(@Param('id') id: string, @Body() dto: AtualizarCondominioDto) { return this.service.atualizar(id, dto); }

  @Patch(':id/bloquear')
  @Roles('admin', 'master')
  bloquear(@Param('id') id: string) { return this.service.atualizar(id, { ativo: false }); }

  @Patch(':id/desbloquear')
  @Roles('admin', 'master')
  desbloquear(@Param('id') id: string) { return this.service.atualizar(id, { ativo: true }); }

  @Delete(':id')
  @Roles('admin', 'master')
  excluir(@Param('id') id: string) { return this.service.excluir(id); }

  @Post(':id/supervisores/:supervisorId')
  @Roles('admin', 'master')
  vincular(@Param('id') id: string, @Param('supervisorId') supervisorId: string) {
    return this.service.vincularSupervisor(id, supervisorId);
  }

  @Delete(':id/supervisores/:supervisorId')
  @Roles('admin', 'master')
  desvincular(@Param('id') id: string, @Param('supervisorId') supervisorId: string) {
    return this.service.desvincularSupervisor(id, supervisorId);
  }
}
