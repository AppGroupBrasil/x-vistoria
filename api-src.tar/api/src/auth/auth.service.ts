import { Injectable, UnauthorizedException, ConflictException, BadRequestException, Inject, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { SQL } from '../database/database.module';
import * as bcrypt from 'bcrypt';
import { randomUUID } from 'node:crypto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @Inject(SQL) private readonly sql: any,
    private readonly jwtService: JwtService,
  ) {}

  async login(email: string, senha: string) {
    const [usuario] = await this.sql`
      SELECT u.*, e.nome as empresa_nome
      FROM usuarios u
      LEFT JOIN empresas e ON e.id = u.empresa_id
      WHERE u.email = ${email} AND u.ativo = true
    `;

    if (!usuario) {
      this.logger.warn(`Login falhou: email não encontrado (${email})`);
      throw new UnauthorizedException('Credenciais inválidas');
    }

    const senhaOk = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaOk) {
      this.logger.warn(`Login falhou: senha incorreta (${email})`);
      throw new UnauthorizedException('Credenciais inválidas');
    }

    await this.sql`
      UPDATE usuarios SET ultimo_login = NOW() WHERE id = ${usuario.id}
    `;

    const payload = {
      sub: usuario.id,
      email: usuario.email,
      role: usuario.role,
      empresa_id: usuario.empresa_id,
      pode_editar: usuario.pode_editar || false,
      pode_excluir: usuario.pode_excluir || false,
    };

    this.logger.log(`Login bem-sucedido: ${email} (${usuario.role})`);

    return {
      access_token: this.jwtService.sign(payload),
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        role: usuario.role,
        empresa_id: usuario.empresa_id,
        empresa_nome: usuario.empresa_nome,
        avatar_url: usuario.avatar_url,
        pode_editar: usuario.pode_editar || false,
        pode_excluir: usuario.pode_excluir || false,
      },
    };
  }

  async me(userId: string) {
    const [usuario] = await this.sql`
      SELECT u.id, u.nome, u.email, u.role, u.telefone, u.avatar_url,
             u.empresa_id, u.pode_editar, u.pode_excluir,
             e.nome as empresa_nome, e.logo_url as empresa_logo
      FROM usuarios u
      LEFT JOIN empresas e ON e.id = u.empresa_id
      WHERE u.id = ${userId} AND u.ativo = true
    `;
    if (!usuario) throw new UnauthorizedException();
    return usuario;
  }

  async register(data: {
    empresa_nome: string;
    cnpj?: string;
    nome: string;
    email: string;
    senha: string;
    telefone?: string;
  }) {
    const [existing] = await this.sql`
      SELECT id FROM usuarios WHERE email = ${data.email}
    `;
    if (existing) {
      throw new ConflictException('Email já cadastrado');
    }

    if (data.cnpj) {
      const [existingEmpresa] = await this.sql`
        SELECT id FROM empresas WHERE cnpj = ${data.cnpj}
      `;
      if (existingEmpresa) {
        throw new ConflictException('CNPJ já cadastrado');
      }
    }

    const senhaHash = await bcrypt.hash(data.senha, 12);

    const [empresa] = await this.sql`
      INSERT INTO empresas (nome, cnpj, email, telefone)
      VALUES (${data.empresa_nome}, ${data.cnpj || null}, ${data.email}, ${data.telefone || null})
      RETURNING id
    `;

    const [usuario] = await this.sql`
      INSERT INTO usuarios (empresa_id, nome, email, senha_hash, role, telefone, pode_editar, pode_excluir)
      VALUES (${empresa.id}, ${data.nome}, ${data.email}, ${senhaHash}, 'admin', ${data.telefone || null}, true, true)
      RETURNING id, nome, email, role, empresa_id
    `;

    this.logger.log(`Nova empresa cadastrada: ${data.empresa_nome} (${data.email})`);

    const payload = {
      sub: usuario.id,
      email: usuario.email,
      role: usuario.role,
      empresa_id: usuario.empresa_id,
      pode_editar: true,
      pode_excluir: true,
    };

    return {
      access_token: this.jwtService.sign(payload),
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        role: usuario.role,
        empresa_id: usuario.empresa_id,
        empresa_nome: data.empresa_nome,
        avatar_url: null,
        pode_editar: true,
        pode_excluir: true,
      },
    };
  }

  async esqueciSenha(email: string) {
    const [usuario] = await this.sql`
      SELECT id FROM usuarios WHERE email = ${email} AND ativo = true
    `;

    // Always return success to prevent email enumeration
    if (!usuario) {
      this.logger.warn(`Esqueci senha: email não encontrado (${email})`);
      return { message: 'Se o email existir, você receberá um link de redefinição.' };
    }

    const token = randomUUID();
    const expira = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await this.sql`
      UPDATE usuarios
      SET reset_token = ${token}, reset_token_expira = ${expira}
      WHERE id = ${usuario.id}
    `;

    // NOTE: Email service (SES) integration pending
    this.logger.log(`Reset token gerado para ${email}: ${token}`);

    return { message: 'Se o email existir, você receberá um link de redefinição.' };
  }

  async redefinirSenha(token: string, novaSenha: string) {
    const [usuario] = await this.sql`
      SELECT id FROM usuarios
      WHERE reset_token = ${token}
        AND reset_token_expira > NOW()
        AND ativo = true
    `;

    if (!usuario) {
      throw new BadRequestException('Token inválido ou expirado');
    }

    const senhaHash = await bcrypt.hash(novaSenha, 12);

    await this.sql`
      UPDATE usuarios
      SET senha_hash = ${senhaHash}, reset_token = NULL, reset_token_expira = NULL
      WHERE id = ${usuario.id}
    `;

    this.logger.log(`Senha redefinida com sucesso (usuario ${usuario.id})`);

    return { message: 'Senha redefinida com sucesso' };
  }
}
